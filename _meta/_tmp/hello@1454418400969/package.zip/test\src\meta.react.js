var react = require("react");

var meta = react.createClass({
    render: function() {
      return (
        <html>
          <head>
            <title>css test</title>
            <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,500'
            rel='stylesheet' type='text/css'/>
          </head>
          );
        }
});

module.exports = meta;
